---
layout: home
title: "Blog"
permalink: /blog/
author_profile: true
---
