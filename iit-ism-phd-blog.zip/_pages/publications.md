---
title: "Publications"
permalink: /pages/publications/
---

Below is a short list. For a complete and updated list, see my [Google Scholar](/).

{% for p in site.data.publications %}
- **{{ p.title }}** ({{ p.year }}) — {{ p.authors }}. _{{ p.venue }}_. {% if p.link %}[Link]({{ p.link }}){% endif %}
{% endfor %}
