---
title: "Research"
permalink: /pages/research/
---

My current interests include:

- Hybrid forecasting (LSTM + ARIMA) for financial time series
- Crypto market microstructure and liquidity
- Policy impacts on technology adoption (UTAUT extensions)

I publish code and datasets when possible to encourage **reproducible research**.
