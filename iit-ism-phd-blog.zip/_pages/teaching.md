---
title: "Teaching"
permalink: /pages/teaching/
---

- Guest Lecture: **Time Series for Crypto** — IIT (ISM) seminar (slides & code coming soon)
- Workshop: **Reproducible Finance Research with Python**
