---
title: "Contact"
permalink: /pages/contact/
---

- **Email**: your.email@iitism.ac.in  
- **Office**: IIT (ISM) Dhanbad  
- **GitHub**: [your-username](https://github.com/your-username)

For collaboration, please send a short note about your project and timeline.
