---
title: "LSTM + ARIMA: What Works in Practice?"
categories: [research]
tags: [lstm, arima, forecasting, crypto]
---

Notes from my experiments blending **LSTM** and **ARIMA** for price forecasting. 
I'll share baselines, cross-validation tips, and pitfalls to avoid.
